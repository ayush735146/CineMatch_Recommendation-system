# CineMatch System Flow

```text
User ID
   ↓
Load User Profile
   ↓
Check Previously Rated Movies
   ↓
Predict Ratings for Unrated Movies
   ↓
Sort Predicted Ratings
   ↓
Select Top 5 Movies
   ↓
Display Personalized Recommendations
```
